class User:
    def __init__(self, email, pwd):
        self.email = email
        self.password = pwd

class Contact:
    def __init__(self,name, mobile, city, profession):
        self.name = name
        self.mobile = mobile
        self.city = city
        self.profession = profession

c_id = []