class Admin:
    def __init__(self, email,pswrd):
        self.email = email
        self.pswrd = pswrd
        
