from flask import Flask,render_template,request,make_response
from galleryModel import galleryModel
from galleryViews import*

def getModel():
    return galleryModel("localhost","root","1010","mygallery")

app = Flask("__name__")

@app.route('/')
def login():
    return render_template("login.html")

@app.route('/loginInProgress',methods=["post"])
def loginInProgress():
    user = request.form["username"]
    password = request.form["password"]
    u = User(user, password)    
    model = getModel()
    if model.login(u):
        response = make_response(render_template("home.html"))
        response.set_cookie("id" , str(model.getUserID(u)))
        return response
    return render_template("login.html")


def convertTOBinary(filename):
    with open(filename,"rb") as file:
        bData = file.read()
    return bData        

def convertTOFile(binaryData,dataList):
    with open("wb") as file:
        file.write(binaryData)    

@app.route('/addImage',methods = ['post'])
def addingImage():
    f = request.files["image"]
    f.save(f"static\\images\\{f.filename}")
    model = getModel()
    model.insertImage(request.cookies["id"],f.filename)
    return render_template("home.html")



@app.route("/showMyImages")
def showMyImages():
    userID = request.cookies["id"]
    model = getModel()
    images = model.getMyImages(int(userID))
    print(images)
    return render_template("myGallery.html",images=images)


if __name__=='__main__':
    app.run(debug=True)