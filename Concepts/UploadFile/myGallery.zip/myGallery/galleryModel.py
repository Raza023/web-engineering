import pymysql
class galleryModel:
    def __init__(self,host,user,password,database):
        self.host=host
        self.user=user
        self.password=password
        self.database=database
        self.connection=None
        try:
            self.connection=pymysql.connect(host=self.host, user=self.user,password=self.password,database=self.database)
        except Exception as e:
            print("There is error in connection",str(e))

    
    def getUserID(self,user):
        cursor=None
        try:
            if self.connection != None:
                cursor = self.connection.cursor()
                query = "Select user_id from users where user_name=%s;"
                args = (user.username)
                cursor.execute(query,args)
                return cursor.fetchone()[0]
        except Exception as e:
            print("Exception: ", str(e))
        finally:
            if cursor != None:
                cursor.close()
    
    def insertImage(self,uid,imageName):
        cursor = None
        try:
            if self.connection != None:
                cursor = self.connection.cursor()
                query = "insert into images (user_id,imagename) values ( %s , %s)"
                args = (uid,imageName)
                cursor.execute(query, args)
                self.connection.commit()
            
        except Exception as e:
            print("Exception in checkUserExist", str(e))
        finally:
            if cursor != None:
                cursor.close()
    
    def getMyImages(self,uid):
        cursor=None
        try:
            if self.connection != None:
                cursor = self.connection.cursor()
                query = "Select imagename from images where user_id=%s;"
                args = (uid)
                cursor.execute(query,args)
                a= (cursor.fetchall())
                
                return a
        except Exception as e:
            print("Exception: ", str(e))
        finally:
            if cursor != None:
                cursor.close()
    
    def login(self,user):
        cursor = None
        flag = False
        try:
            if self.connection != None:
                cursor = self.connection.cursor()
                query = "Select* from users;"
                cursor.execute(query)
                users = cursor.fetchall()
                for usr in users:
                    if user.username==usr[1] and user.password==usr[2] :
                        flag = True
                        if cursor != None:
                            cursor.close()
                        return  flag
                return flag
        except Exception as e:
            print("Exception: ", str(e))
        finally:
            if cursor != None:
                cursor.close()
                return flag
